angular.module('app.controllers', [])
  
.controller('connectItCtrl', function($scope) {

})
   
.controller('chatCtrl', function($scope) {

})
   
.controller('inboxCtrl', function($scope) {

})
   
.controller('needARideCtrl', function($scope) {

})
      
.controller('settingsCtrl', function($scope) {

})
   
.controller('offerARideCtrl', function($scope) {

})
   
.controller('overviewCtrl', function($scope) {

})
   
.controller('routineCtrl', function($scope) {

})
 